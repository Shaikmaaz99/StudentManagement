package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;
import com.example.demo.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;
	@Override
	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student) ;
	}
	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}
	@Override
	public Student getStudentById(int studentId) {
		// TODO Auto-generated method stub
		return studentRepository.findById(studentId).get();
	}
	@Override
	public void removeStudentById(int studentId) {
		// TODO Auto-generated method stub
		Student student=getStudentById(studentId);
		studentRepository.deleteById(student.getStudentId());
		
	}
	@Override
	public Student updateStudentById(int studentId, Student newstudentdetails) {
		// TODO Auto-generated method stub
		Student existingstudentinfo=getStudentById(studentId);
		existingstudentinfo.setsName(newstudentdetails.getsName());
		existingstudentinfo.setsMarks(newstudentdetails.getsMarks());
		return studentRepository.save(newstudentdetails);
	}
	

	

}
