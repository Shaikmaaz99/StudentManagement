package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Student;

public interface StudentService {
	public Student addStudent(Student student);
	public List<Student> getAllStudents();
	public Student getStudentById(int studentId);
	public void removeStudentById(int studentId);
	public Student updateStudentById(int studentId,Student student);
}
